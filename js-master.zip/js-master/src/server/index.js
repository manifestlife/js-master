// @flow

/* eslint-disable no-console */

import Dog from '../shared/dog';

const toby = new Dog('Toby');

console.log(toby.bark());
